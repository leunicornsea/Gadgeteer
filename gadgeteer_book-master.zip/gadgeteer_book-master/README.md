gadgeteer_book
==============

The code for the book 'Getting Started with .Net Gadgeteer' by Simon Monk.